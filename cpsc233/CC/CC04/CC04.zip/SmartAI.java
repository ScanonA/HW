public class SmartAI extends Player {

  public SmartAI(int id) {
    super(id);
  }

  public SmartAI(SmartAI toCopy) {
    super(toCopy);
  }

  public int chooseMove() {
    return 0;
  }

  public String toString() {
    String stringHolder = super.toString();
    return stringHolder;
  }

}
